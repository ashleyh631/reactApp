import {
  ADD_TASK,
  SELECT_TASK,
  DESELECT_TASK,
  PUBLISH_TASK,
  EDIT_PENDING_TASK,
  DELETE_TASK,
} from '../constants/action_types';

export function addTask(payload) {
  return {
    type: ADD_TASK,
    id: payload.id,
  };
}

export function selectTask(payload) {
  return {
    type: SELECT_TASK,
    id: payload.id,
  };
}

export function deselectTask() {
  return {
    type: DESELECT_TASK,
  };
}

// export function publishTask(payload) {
//     return {
//         type: PUBLISH_TASK,
//     };
// }

// export function addTask(payload) {
//     return {
//         type:ADD_TASK,
//         id: payload.id,
//     };
// }

export function editPendingTask(task) {
  return {
    type: EDIT_PENDING_TASK,
    task,
  };
}

export function publishTask(id, title, value, effort) {
  return {
    type: PUBLISH_TASK,
    id,
    title,
    value,
    effort,
  };
}

export function deleteTask(id) {
  return {
    type: DELETE_TASK,
    id,
  };
}
