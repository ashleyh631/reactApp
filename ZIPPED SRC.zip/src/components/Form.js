import React from 'react';
// import './CreateTask';
import styles from '../css/button.css';

// const Form = connect(
//   mapStateToProps,
//   mapDispatchToProps
// )(TodoForm)

const TodoForm = props => (
  <div>
    <form className={styles.newTask}>
      <h1 className={styles.header}>Pending Task</h1>
      <button
        className={styles.buttons}
        type="submit"
        onClick={props.createTask}
      >
        Create Task
      </button>
      <input
        type="text"
        placeholder="Title"
        value={props.title}
        // onChange={props.handleChange}
      />
      <input
        type="text"
        placeholder="Effort"
        value={props.effort}
        // onChange={props.handleChange}
      />
      <input
        type="text"
        placeholder="Value"
        value={props.value}
        // onChange={props.handleChange}
      />
      <button type="submit" className={styles.buttons} onClick={props.saveTask}>
        Save Task
      </button>
      <button
        className={styles.buttons}
        type="submit"
        onClick={props.deleteTask}
      >
        Delete Task
      </button>
    </form>

    <form className={styles.newTask}>
      <h1 className={styles.header}> Task List </h1>
    </form>
  </div>
);

// const mapDispatchToProps = (dispatch) => {
//   return {
//     addTask();
//   };
// };

// export default connect(
//   mapStateToProps,
//   mapDispatchToProps,
// )(TodoForm)
export default TodoForm;
