// import React from 'react';
// import {ADD_TASK, SELECT_TASK, DESELECT_TASK, PUBLISH_TASK,} from '../constants/action_types';
// import './Form';

// const CreateTask = props => (
//  Tasks = [
//      {id: null }
//  ]
//     <div></div>

// );
// export default CreateTask;
