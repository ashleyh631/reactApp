import React from 'react';
import './Form';
import './CreateTask';
import ToDo from '../App';

const ToDo = ({toDos}) => {
    const toDoList = toDos.length ? (
        todos.map(toDo => {
            return (
                <div key={toDo.id}>
                    <span onClick={ () => {deleteToDo(ToDo.id)}} >{toDo.content}</span>
                </div>
            )
    })
    
    ) : (
        <p >You have no tasks left </p>
    )

    return (
        <div>
            {toDoList}
        </div>
    )
}

export default ToDo;