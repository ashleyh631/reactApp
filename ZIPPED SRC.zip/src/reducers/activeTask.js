import {
  ADD_TASK,
  SELECT_TASK,
  DESELECT_TASK,
  PUBLISH_TASK,
} from '../constants/action_types';

const intialState = {};
function activeTaskReducer(state = intialState, action) {
  switch (action.type) {
    case ADD_TASK:
      return action.id;
    case SELECT_TASK:
      return action.id;
    case DESELECT_TASK:
      return '';
    case PUBLISH_TASK:
      return '';
    default:
      return state;
  }
}

export default activeTaskReducer;
