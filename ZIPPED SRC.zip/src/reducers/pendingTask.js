import {
  ADD_TASK,
  EDIT_PENDING_TASK,
  PUBLISH_TASK,
  DELETE_TASK,
} from '../constants/action_types';

const initialState = {};
function pendingTaskReducer(state = initialState, action) {
  switch (action.type) {
    case ADD_TASK:
      return {
        id: action.id,
        title: '',
        value: undefined,
        effort: undefined,
      };
    case EDIT_PENDING_TASK:
      return action.task;
    case PUBLISH_TASK:
      return {};
    case DELETE_TASK:
      return action.id;

    default:
      return state;
  }
}

export default pendingTaskReducer;
