import React from 'react';
import Form from './components/Form';

const createTask = () => {
  alert('Create Task');
};
const deleteTask = () => {
  alert('Delete task');
};
const saveTask = () => {
  alert('Save Task');
};
const Tasks = props => (
  <div>
    <Form
      deleteTask={() => {
        deleteTask();
      }}
      createTask={() => {
        createTask();
      }}
      saveTask={() => {
        saveTask();
      }}
    />
  </div>
);

export default Tasks;
