export const PUBLISH_TASK = 'PUBLISH_TASK';
export const ADD_TASK = 'ADD_TASK';
export const SELECT_TASK = 'SELECT_TASK';
export const EDIT_PENDING_TASK = 'EDIT_PENDING_TASK';
export const DELETE_TASK = 'DELETE_TASK';
export const UPDATE_TASK = 'UPDATE_TASK';
export const DESELECT_TASK = 'DESELECT_TASK';